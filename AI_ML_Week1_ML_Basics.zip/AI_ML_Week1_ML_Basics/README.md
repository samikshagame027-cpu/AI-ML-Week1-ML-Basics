# AI/ML Internship – Week 1: ML Basics

This repository contains solutions to the Week 1 practice questions.

## Topics
- Supervised vs Unsupervised Learning
- Linear Regression
- Data Preprocessing

## Practice Questions Covered
1. Load a CSV using pandas and display the first 10 rows.
2. Split a dataset into training and testing sets using scikit-learn.
3. Train a Linear Regression model and evaluate it using the R² score.
4. Predict house prices based on area.

## Requirements
Install Python 3, then run:

```bash
pip install -r requirements.txt
```

## Dataset
The program uses `house_prices.csv`, included in this repository. The sample dataset is for practice and learning only.

## Run
From this folder, run:

```bash
python week1_ml_basics.py
```

The script prints the first 10 rows, train/test sizes, the model's R² score, and a sample house-price prediction.

## Notes
- The R² score is a regression evaluation metric, not classification accuracy.
- Results depend on the dataset and train/test split.
