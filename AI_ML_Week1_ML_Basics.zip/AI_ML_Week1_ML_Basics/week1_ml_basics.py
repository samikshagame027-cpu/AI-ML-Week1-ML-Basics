"""
AI/ML Internship - Week 1: ML Basics
Practice questions:
1. Load a CSV and print the first 10 rows.
2. Split data into train/test sets.
3. Train Linear Regression and evaluate with R².
4. Predict house price from area.
"""

from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error

DATA_PATH = Path(__file__).with_name("house_prices.csv")


def main():
    # Q1: Load CSV and display first 10 rows
    data = pd.read_csv(DATA_PATH)
    print("\nQ1. First 10 rows of the dataset:")
    print(data.head(10).to_string(index=False))

    # Inputs (X) and target (y)
    X = data[["Area"]]
    y = data["Price"]

    # Q2: Split dataset into training and testing data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    print("\nQ2. Train/test split:")
    print(f"Training rows: {len(X_train)}")
    print(f"Testing rows: {len(X_test)}")

    # Q3: Train Linear Regression and evaluate it
    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    print("\nQ3. Linear Regression evaluation:")
    print(f"R² score: {r2_score(y_test, y_pred):.3f}")
    print(f"Mean Absolute Error: {mean_absolute_error(y_test, y_pred):,.2f}")

    # Q4: Predict the price for a sample area
    sample_area = 1500
    sample_input = pd.DataFrame({"Area": [sample_area]})
    predicted_price = model.predict(sample_input)[0]
    print("\nQ4. House price prediction:")
    print(f"Area: {sample_area} sq. ft.")
    print(f"Predicted price: {predicted_price:,.2f} (dataset price units)")


if __name__ == "__main__":
    main()
